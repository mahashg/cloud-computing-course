package backtype.storm.metric.api;

public interface IStatefulObject {
    Object getState();
}
