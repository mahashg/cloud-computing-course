package backtype.storm.topology;

public interface SpoutDeclarer extends ComponentConfigurationDeclarer<SpoutDeclarer> {
    
}
