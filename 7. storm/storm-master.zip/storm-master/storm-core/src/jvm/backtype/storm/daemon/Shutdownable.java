package backtype.storm.daemon;

public interface Shutdownable {
    public void shutdown();
}