package storm.trident.operation;

public interface EachOperation extends Operation {
   
}
